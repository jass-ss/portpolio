
/* 쿠키: 사용자의 컴퓨터에 파일(문자열) 형태로 저장하는 정보 

    쿠키의 생명주기
    쿠키이름 = 쿠키값; path=/ (쿠키의 document 위치값); expires=해당쿠키가 삭제될 날짜;

*/

const btnView = document.querySelector(".view"); 
const btnDel = document.querySelector(".del");
const popup = document.querySelector("#popup"); 
const btnClose = popup.querySelector(".close"); 

setCookie('todaty','done',1)
console.log(document.cookie.indexOf('today=done')) // 해당 문자열을 갖은 쿠키가 쿠키들중 몇번째에 있는지 반환(0~). -1은 없다는 뜻. 


/*
function setCookie(name, val, due){
    const today = new Date();
    const day = today.getDate();
    today.setDate(day + due);
    const duedate = today.toGMTString();
    document.cookie = `${name}=${val}; path=/; expire = ${duedate}`
}
*/

//쿠키확인 버튼 이벤트 
btnView.addEventListener("click", e=>{
    e.preventDefault(); 
    console.log(document.cookie); 
});

//쿠키 삭제 버튼 이벤트 
btnDel.addEventListener("click", e=>{
    e.preventDefault(); 
    setCookie("today","done", 0); 
    alert("쿠키를 삭제했습니다");
}); 

//팝업 닫기 버튼 클릭 이벤트 
btnClose.addEventListener("click", e=>{
    e.preventDefault(); 
    popup.style.display = "none";
})

 
 
//쿠키 생성 함수 
function setCookie(name, val, due){
    const today = new Date(); 
    const day = today.getDate(); 
    today.setDate(day + due); 
    const duedate = today.toGMTString();  
    console.log(duedate)
    document.cookie = `${name}=${val}; path=/; expires=${duedate}`;
    console.log(document.cookie)
}